## 2021-05-07
- Plugin names and translation keys changed! (update extension and clear all caches!)
- Category menu can be deactivated now
- Category menu has active state and style
- Category menu is now default bootstrap navbar component
- imagesLoaded library included
- Preview images for list layout added
- Image cropping added

## 2021-05-05
- Language fixes
- CSS changes for card hover animations
- Version 0.0.1 alpha released
